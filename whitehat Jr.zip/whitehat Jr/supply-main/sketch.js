
const Engine = Matter.Engine;
const World = Matter.World;
const Bodies = Matter.Bodies;
const Body = Matter.Body;

var side1,side2,side3;
var ball
function preload()
{
	//helicopterIMG=loadImage("helicopter.png")
	ballIMG=loadImage("ball.png")
}

function setup() {
	createCanvas(1350, 700);
	//ballSprite = createSprite(200,200,);
	rectMode(CENTER);
	

	//ballSprite=createSprite(width/2, 80, 10,10);
	//ballSprite.addImage(ballIMG)
	//ballSprite.scale=0.2

	//helicopterSprite=createSprite(width/2, 200, 10,10);
	//helicopterSprite.addImage(helicopterIMG)
	//helicopterSprite.scale=0.6

	groundSprite=createSprite(width/2, height-35, width,10);
	groundSprite.shapeColor=color("yellow")


	engine = Engine.create();
	world = engine.world;

	ballSprite = Bodies.circle(200,200, 20,20);
	World.add(world, ballSprite);
	

	//Create a Ground
	ground = Bodies.rectangle(width/2, 650, width, 10 , {isStatic:true} );
 	World.add(world, ground);

	side1 = new Box(1200,655,200,20);
	side2 = new Box(1110,610,20,100);
	side3 = new Box(1300,610,20,100);

	Engine.run(engine);
  
}


function draw() {
  rectMode(CENTER);
  background(0);
  ballSprite.x= ballBody.position.x 
ballSprite.y= ballBody.position.y 
  //keyPressed();

  side1.display();
  side2.display();
  side3.display();

ballSprite.display();

  drawSprites();
 
}

function keyPressed() {
 if (keyCode === UP_ARROW) {
   Matter.Body.applyForce(paperObject.body,paperObject.body.position,{x:85,y:-85});

  }
}



