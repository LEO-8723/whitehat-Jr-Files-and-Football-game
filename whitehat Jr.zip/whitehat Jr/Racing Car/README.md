# synchronousBallMovement
Ball moving synchronously
